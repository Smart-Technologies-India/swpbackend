import { InputType, Int, Field, registerEnumType } from '@nestjs/graphql';
import { IsNotEmpty, IsOptional } from 'class-validator';

import { FormType, PaymentStatus, Status, queryStatus } from '@prisma/client';

registerEnumType(PaymentStatus, {
  name: 'PaymentStatus',
});

@InputType()
export class CreatePaymentInput {
  @IsNotEmpty()
  @Field(() => Int)
  form_id: number;

  @IsNotEmpty()
  @Field(() => Int)
  deptuser_id: number;

  @IsNotEmpty()
  @Field(() => Int)
  user_id: number;

  @IsNotEmpty()
  @Field(() => Int)
  type1: number;

  @IsNotEmpty()
  @Field(() => Int)
  amount1: number;

  @IsNotEmpty()
  @Field(() => Int)
  type2: number;

  @IsNotEmpty()
  @Field(() => Int)
  amount2: number;

  @IsNotEmpty()
  @Field(() => Int)
  type3: number;

  @IsNotEmpty()
  @Field(() => Int)
  amount3: number;

  @IsNotEmpty()
  @Field(() => Int)
  daycount: number;

  @IsNotEmpty()
  @Field(() => Int)
  paymentamout: number;

  @IsNotEmpty()
  @Field(() => FormType)
  form_type: FormType;

  @IsNotEmpty()
  @Field(() => PaymentStatus)
  paymentstatus: PaymentStatus;
}
