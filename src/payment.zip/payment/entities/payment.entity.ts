import { ObjectType, Field, Int } from '@nestjs/graphql';
import { FormType, PaymentStatus, PaymentType } from '@prisma/client';

@ObjectType()
export class Payment {
  @Field(() => Int)
  id: number;

  @Field(() => Int)
  form_id: number;

  @Field(() => Int)
  deptuser_id: number;

  @Field(() => Int)
  user_id: number;

  @Field(() => Int)
  type1: number;

  @Field(() => Int)
  amount1: number;

  @Field(() => Int)
  type2: number;

  @Field(() => Int)
  amount2: number;

  @Field(() => Int)
  type3: number;

  @Field(() => Int)
  amount3: number;

  @Field(() => Int)
  daycount: number;

  @Field(() => Int)
  paymentamout: number;

  @Field(() => String, { nullable: true })
  reference: string;

  @Field(() => FormType)
  form_type: FormType;

  @Field(() => PaymentType)
  paymentType: PaymentType;

  @Field(() => PaymentStatus)
  paymentstatus: PaymentStatus;

  @Field(() => Date)
  createdAt: Date;

  @Field(() => Date)
  updatedAt: Date;

  @Field(() => Date, { nullable: true })
  deletedAt: Date;
}
